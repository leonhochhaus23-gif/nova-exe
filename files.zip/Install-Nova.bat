@echo off
setlocal
title Install Nova

rem ---- EDIT THIS: the GitHub username from your repo address ----
set "GH_USER=YOUR-USERNAME"
set "GH_REPO=nova-exe"
rem ----------------------------------------------------------------

if /i "%GH_USER%"=="YOUR-USERNAME" (
  echo This file is not set up yet.
  echo Right-click it, choose Edit, and replace YOUR-USERNAME with the GitHub username.
  pause
  exit /b 1
)

set "BASE=https://github.com/%GH_USER%/%GH_REPO%/releases/latest/download"
set "OUT=%USERPROFILE%\Downloads"

echo Downloading Nova. This can take a minute...
call :get Nova-Setup.exe || goto fail
call :get Nova-Tutorial.txt

echo.
echo Starting the installer.
echo If Windows says "Windows protected your PC", click More info, then Run anyway.
if exist "%OUT%\Nova-Tutorial.txt" start "" notepad "%OUT%\Nova-Tutorial.txt"
start "" "%OUT%\Nova-Setup.exe"
exit /b 0

:get
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -UseBasicParsing -Uri '%BASE%/%~1' -OutFile '%OUT%\%~1'"
exit /b %errorlevel%

:fail
echo.
echo Could not download Nova. Check your internet and that the GitHub release exists.
pause
exit /b 1
