# Nova

Nova is my own AI assistant app for Windows: a fast chat for PC problems, error codes, coding and everyday questions. It is free and it works with no account.

## Download

1. Open the [latest release](../../releases/latest).
2. Download **Nova-Setup.exe** and run it. (**Nova-Portable.exe** runs without installing.)
3. If Windows says "Windows protected your PC", click **More info**, then **Run anyway**. The app is not signed, so Windows shows this for every new unsigned app.
4. Read **Nova-Tutorial.txt** from the release for a short guide. If Nova will not install or open, section 3 of that guide lists fixes to try in order.

## What it can do

- Chat with free AI engines. Add a free Gemini key for better answers and pictures.
- Send photos, camera pictures and text or code files.
- Keep your past chats, with search, rename and delete.
- Change colours, including Black and White themes, and pick your own.
- Performance modes for slow computers.
- Optional local AI on your own PC with Ollama.

## Privacy

Your keys and chats stay on your own device. Messages you send to online engines go to those services, so do not type passwords or private company information.

*A hobby project. Not affiliated with any AI company.*
